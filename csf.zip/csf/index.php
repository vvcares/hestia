<?php
error_reporting(NULL);
$TAB = 'CSF';

// Main include
include($_SERVER['DOCUMENT_ROOT']."/inc/main.php");

// Check user
if ($_SESSION['user'] != 'admin') {
    header("Location: /list/user");
    exit;
}

// Header
if(!isset($_GET['action']))
include($_SERVER['DOCUMENT_ROOT'].'/templates/header.html');

// Panel
if(!isset($_GET['action']))
top_panel($user,$TAB);

echo '<div class="l-center units"><div class="l-unit"></div>';

// Data
if(isset($_POST['action']))
	$env=http_build_query($_POST);
if(isset($_GET['action']))
	$env=http_build_query($_GET);

// Run CSF
passthru(VESTA_CMD . "v-csf \"$env\"");

echo '</div><style type="text/css">.l-stat a, .l-header a { text-decoration:none; } td, th { padding:5px; } #CSFajax { height:800px!important; width:100%!important; }</style>';
echo '<link rel="stylesheet" href="images/bootstrap/css/bootstrap.min.css">
m<script src="images/jquery.min.js"></script>
<script src="images/bootstrap/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="images/configserver.css?rnew=3094">';

// Back uri
$_SESSION['back'] = $_SERVER['REQUEST_URI'];

// Footer
include($_SERVER['DOCUMENT_ROOT'].'/templates/footer.html');
